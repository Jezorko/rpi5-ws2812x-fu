#pragma once

#define CMD_NOP 0x00
#define CMD_RESET_ENCODERS 0x02
#define CMD_READ_SYSTIME 0x03
#define CMD_RESET_PICO 0x55
#define CMD_READ_ENCODERS 0xF1
